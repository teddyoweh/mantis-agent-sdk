---
name: py-style
description: Python conventions
---

Use ruff.
